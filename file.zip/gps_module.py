#!/usr/bin/env python3
"""
GPS Module
Handles GPS data parsing and location retrieval
"""

import serial
import time
from threading import Thread, Lock
from utils import logger

class GPSModule:
    """GPS module for location tracking"""
    
    def __init__(self, port='/dev/ttyUSB0', baudrate=9600, timeout=1):
        """
        Initialize GPS module
        
        Args:
            port: Serial port for GPS module
            baudrate: Baud rate for serial communication
            timeout: Serial read timeout
        """
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        
        self.serial_conn = None
        self.running = False
        
        # Current location data
        self.lock = Lock()
        self.latitude = None
        self.longitude = None
        self.last_update = None
        
        # Try to initialize serial connection
        self._initialize()
        
        # Start background thread for continuous reading
        if self.serial_conn:
            self.running = True
            self.reader_thread = Thread(target=self._read_loop, daemon=True)
            self.reader_thread.start()
            logger.info("GPS module initialized and reading")
        else:
            logger.warning("GPS module initialization failed - location unavailable")
    
    def _initialize(self):
        """Initialize serial connection to GPS"""
        try:
            self.serial_conn = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                timeout=self.timeout
            )
            logger.info(f"GPS connected on {self.port}")
        except serial.SerialException as e:
            logger.error(f"GPS connection failed: {e}")
            self.serial_conn = None
        except Exception as e:
            logger.error(f"GPS initialization error: {e}")
            self.serial_conn = None
    
    def _read_loop(self):
        """Continuous reading loop in background thread"""
        while self.running and self.serial_conn:
            try:
                # Read line from GPS
                line = self.serial_conn.readline().decode('ascii', errors='ignore').strip()
                
                if line:
                    self._parse_nmea(line)
                
            except Exception as e:
                logger.error(f"GPS read error: {e}")
                time.sleep(1)
    
    def _parse_nmea(self, sentence):
        """
        Parse NMEA sentence and extract location
        
        Focuses on GPGGA and GPRMC sentences
        """
        try:
            parts = sentence.split(',')
            
            if not parts:
                return
            
            sentence_type = parts[0]
            
            # Parse GPGGA (Global Positioning System Fix Data)
            if sentence_type == '$GPGGA':
                self._parse_gpgga(parts)
            
            # Parse GPRMC (Recommended Minimum Specific GPS/Transit Data)
            elif sentence_type == '$GPRMC':
                self._parse_gprmc(parts)
                
        except Exception as e:
            logger.debug(f"NMEA parse error: {e}")
    
    def _parse_gpgga(self, parts):
        """
        Parse GPGGA sentence
        Format: $GPGGA,time,lat,N/S,lon,E/W,quality,satellites,hdop,altitude,M,geoid,M,age,station*checksum
        """
        try:
            if len(parts) < 10:
                return
            
            # Check if fix quality is valid (not 0)
            quality = parts[6]
            if quality == '0':
                return
            
            # Extract latitude
            lat_raw = parts[2]
            lat_dir = parts[3]
            
            # Extract longitude
            lon_raw = parts[4]
            lon_dir = parts[5]
            
            if lat_raw and lon_raw:
                # Convert to decimal degrees
                latitude = self._nmea_to_decimal(lat_raw, lat_dir)
                longitude = self._nmea_to_decimal(lon_raw, lon_dir)
                
                # Update current location
                with self.lock:
                    self.latitude = latitude
                    self.longitude = longitude
                    self.last_update = time.time()
                
                logger.debug(f"GPS updated: {latitude}, {longitude}")
                
        except Exception as e:
            logger.debug(f"GPGGA parse error: {e}")
    
    def _parse_gprmc(self, parts):
        """
        Parse GPRMC sentence
        Format: $GPRMC,time,status,lat,N/S,lon,E/W,speed,course,date,mag_var,E/W*checksum
        """
        try:
            if len(parts) < 8:
                return
            
            # Check if status is valid (A = active)
            status = parts[2]
            if status != 'A':
                return
            
            # Extract latitude
            lat_raw = parts[3]
            lat_dir = parts[4]
            
            # Extract longitude
            lon_raw = parts[5]
            lon_dir = parts[6]
            
            if lat_raw and lon_raw:
                # Convert to decimal degrees
                latitude = self._nmea_to_decimal(lat_raw, lat_dir)
                longitude = self._nmea_to_decimal(lon_raw, lon_dir)
                
                # Update current location
                with self.lock:
                    self.latitude = latitude
                    self.longitude = longitude
                    self.last_update = time.time()
                
                logger.debug(f"GPS updated: {latitude}, {longitude}")
                
        except Exception as e:
            logger.debug(f"GPRMC parse error: {e}")
    
    def _nmea_to_decimal(self, nmea_coord, direction):
        """
        Convert NMEA coordinate format to decimal degrees
        
        NMEA format: DDMM.MMMM (latitude) or DDDMM.MMMM (longitude)
        
        Args:
            nmea_coord: NMEA coordinate string
            direction: N/S/E/W
        
        Returns:
            Decimal degree coordinate
        """
        # Determine if latitude or longitude based on length
        if len(nmea_coord) > 9:  # Longitude (DDDMM.MMMM)
            degrees = float(nmea_coord[:3])
            minutes = float(nmea_coord[3:])
        else:  # Latitude (DDMM.MMMM)
            degrees = float(nmea_coord[:2])
            minutes = float(nmea_coord[2:])
        
        # Convert to decimal
        decimal = degrees + (minutes / 60.0)
        
        # Apply direction (S and W are negative)
        if direction in ['S', 'W']:
            decimal = -decimal
        
        return round(decimal, 6)
    
    def get_location(self):
        """
        Get current GPS location
        
        Returns:
            Tuple (latitude, longitude) or None if unavailable
        """
        with self.lock:
            if self.latitude is not None and self.longitude is not None:
                # Check if data is recent (within last 10 seconds)
                if self.last_update and (time.time() - self.last_update) < 10:
                    return (self.latitude, self.longitude)
                else:
                    logger.warning("GPS data stale")
            
            return None
    
    def get_location_string(self):
        """
        Get formatted location string
        
        Returns:
            String like "12.345678,78.901234" or "unavailable"
        """
        location = self.get_location()
        
        if location:
            lat, lon = location
            return f"{lat},{lon}"
        else:
            return "unavailable"
    
    def is_available(self):
        """Check if GPS has valid fix"""
        with self.lock:
            if self.latitude is None or self.longitude is None:
                return False
            
            if self.last_update is None:
                return False
            
            # Consider available if updated within last 10 seconds
            return (time.time() - self.last_update) < 10
    
    def cleanup(self):
        """Stop GPS reading and close serial connection"""
        logger.info("Cleaning up GPS module")
        
        self.running = False
        
        # Wait for thread to finish
        if hasattr(self, 'reader_thread') and self.reader_thread.is_alive():
            self.reader_thread.join(timeout=2)
        
        # Close serial connection
        if self.serial_conn and self.serial_conn.is_open:
            self.serial_conn.close()
        
        logger.info("GPS cleanup complete")


# Mock GPS for testing without hardware
class MockGPSModule:
    """Mock GPS module for testing"""
    
    def __init__(self):
        self.latitude = 10.8505  # Example: Thiruvananthapuram
        self.longitude = 76.2711
        logger.info("Mock GPS initialized")
    
    def get_location(self):
        """Return mock location"""
        return (self.latitude, self.longitude)
    
    def get_location_string(self):
        """Return formatted mock location"""
        return f"{self.latitude},{self.longitude}"
    
    def is_available(self):
        """Mock GPS is always available"""
        return True
    
    def cleanup(self):
        """No cleanup needed for mock"""
        pass
